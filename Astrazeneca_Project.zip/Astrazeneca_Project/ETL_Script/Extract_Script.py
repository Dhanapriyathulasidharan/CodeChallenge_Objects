from pyspark.sql import sparkSession

spark= sparkSession.builder.appName(DataExtraction).getOrCreate()

df=spark.read.json("C:\Users\Victus\Documents\Dhanapriya\Astrazeneca_Project\Source\DataSet1.json")

df.write.mode("overwrite").parquet("C:\Users\Victus\Documents\Dhanapriya\Astrazeneca_Project\Destination\Extracted_data.parquet")

spark.stop()

