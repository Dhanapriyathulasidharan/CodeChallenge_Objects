from pyspark.sql import SparkSession

from pyspark.sql.functions import col

spark = SparkSession.builder.appName("DataTransformation").getOrCreate()

df = spark.read.parquet("C:\Users\Victus\Documents\Dhanapriya\Astrazeneca_Project\Destination\Extracted_data.parquet")

def clean_data(df,dedup):
    if dedup==True:
     df1=df.na.drop("any").dropDuplicates() 
     return df1
    else:
     df1 = df.na.drop("any")
     return df1
     
transformed_df = df1.select("results.safetyreportid", "results.serious", "results.seriousnessdeath", "results.receivedate", "results.fulfillexpeditecriteria", 
"results.patient.patientsex", "results.patient.reaction.reactionmeddrapt", "results.patient.drug.medicinalproduct")
.where(col("patient.drug.openfda.pharm_class_epc") in ("Thiazide Diuretic","Tumor Necrosis Factor Blocker"))

transformed_df.coalesce(1).write.mode("overwrite").parquet("C:\Users\Victus\Documents\Dhanapriya\Astrazeneca_Project\Destination\Transformed_data.parquet")
spark.stop()

