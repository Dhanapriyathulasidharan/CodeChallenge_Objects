from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("Dataloading").enableHiveSupport().getOrCreate()

df = spark.read.parquet("C:\Users\Victus\Documents\Dhanapriya\Astrazeneca_Project\Destination\Transformed_data.parquet")

df.write.mode("overwrite").option("path","C:\Users\Victus\Documents\Dhanapriya\Astrazeneca_Project\Internal_Table_Path").saveAsTable("DEST_MGD_TB")
spark.stop()
