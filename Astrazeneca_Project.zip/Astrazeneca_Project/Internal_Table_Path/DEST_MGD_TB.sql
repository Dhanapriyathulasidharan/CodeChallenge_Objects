CREATE TABLE DEST_MGD_TB (
    safetyreportid STRING,
    serious INT,
    seriousnessdeath STRING,
    receivedate STRING,
    fulfillexpeditecriteria STRING,
    patientsex STRING,
    reactionmeddrapt STRING,
    medicinalproduct STRING
)
STORED AS ORC;