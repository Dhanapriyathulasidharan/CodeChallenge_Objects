# PySpark ETL Process for Adverse Events Data with makefile usage

## Table of Contents
 => Introduction
 => ETL Process Steps
 => Makefile Integration
 => Usage


## Introduction :
This document provides instructions on how to use the PySpark ETL process to extract specific fields related to adverse events data. The ETL process will utilize the OpenFDA API to query and retrieve the required data. The process will also incorporate data partitioning and use a Makefile for efficient execution.

## ETL Process Steps :

1. Nested JSON data retrieved from given API Query and saved in local path.
   
2. PySpark ETL Process:
   - Created a 3 PySpark script to implement the ETL process.

    (i)Extract_Script.py
   - Imported the necessary PySpark modules and define the necessary configuration parameters such as query parameters, and output file paths, and create the sparksession.
          from pyspark.sql import sparkSession
          spark= sparkSession.builder.appName(DataExtraction).getOrCreate()
   - Read the JSON data from the local path and flattened the nested structure in the DataFrame
	  df=spark.read.json("C:\Users\Victus\Documents\Dhanapriya\Astrazeneca_Project\Source\DataSet1.json")
   - Saved the extracted data to the desired output file location and stopped the spark session.
          df.write.mode("overwrite").parquet("C:\Users\Victus\Documents\Dhanapriya\Astrazeneca_Project\Destination\Extracted_data.parquet")
          spark.stop() 

   (ii)Transform_Script.py
   - Imported the necessary PySpark modules and define the necessary configuration parameters.
	  from pyspark.sql import SparkSession
          from pyspark.sql.functions import col
          spark = SparkSession.builder.appName("DataTransformation").getOrCreate()
   - Read the extracted parquet data from the file location into dataframe
	  df = spark.read.parquet("C:\Users\Victus\Documents\Dhanapriya\Astrazeneca_Project\Destination\Extracted_data.parquet")
   - Transformed the data (e.g., selecting specific columns, applying filters, etc.) 
	  transformed_df = df1.select("results.safetyreportid", "results.serious", "results.seriousnessdeath", "results.receivedate", "results.fulfillexpeditecriteria", 
                          "results.patient.patientsex", "results.patient.reaction.reactionmeddrapt", "results.patient.drug.medicinalproduct")
			  .where(col("patient.drug.openfda.pharm_class_epc") in ("Thiazide Diuretic","Tumor Necrosis Factor Blocker"))
   - Considering the implementation of data partitioning for efficient data storage and processing. I have used coalesce partitioning to decrease the shuffling, 
	so the performance will increase and data can be retrieved in a single file. Then, saved the transformed data to the desired output file location and stopped the spark session.
	  transformed_df.coalesce(1).write.mode("overwrite").parquet("C:\Users\Victus\Documents\Dhanapriya\Astrazeneca_Project\Destination\Transformed_data.parquet")
          spark.stop()

   (iii)Load_Script.py
   - Imported the necessary PySpark modules and define the necessary configuration parameters.
	  from pyspark.sql import SparkSession
   - Enabled the hive support in sparksession
	  spark = SparkSession.builder.appName("Dataloading").enableHiveSupport().getOrCreate()
   - Read the transformed parquet data from the file location into data frame
	  df = spark.read.parquet("C:\Users\Victus\Documents\Dhanapriya\Astrazeneca_Project\Destination\Transformed_data.parquet")
   - Loaded the data into the hive internal table in the desired hive location and stopped the spark session.
          df.write.mode("overwrite").option("path","C:\Users\Victus\Documents\Dhanapriya\Astrazeneca_Project\Internal_Table_Path").saveAsTable("DEST_MGD_TB")
          spark.stop()

## Makefile Integration:
   - Created a Makefile to automate the execution of the PySpark ETL process.
   - Define targets and the prerequisites in the Makefile for each step of the ETL process, such as data extraction, transformation, and loading.
		.PHONY: Extract Transform Load
   - Specify the dependencies between the targets to ensure proper execution order.
		Extract: 
		spark-submit --master local --deploy-mode cluster --driver-memory 8g --executor-memory 16g --executor-cores 2  Extract_Script.py > logs.txt 2>&1
                Transform: 
		spark-submit --master local --deploy-mode cluster --driver-memory 8g --executor-memory 16g --executor-cores 2  Transform_Script.py > logs.txt 2>&1
 		Load:
		spark-submit --master local --deploy-mode cluster --driver-memory 8g --executor-memory 16g --executor-cores 2  Load_Script.py > logs.txt 2>&1
		pipeline: Extract Transform Load
   - Included additional commands to fetch the event logs in the text file.
		"> logs.txt 2>&1"
   - By running `make pipeline`, we can execute the complete ETL process in a single command, ensuring that the steps are executed in the correct order

## Usage :

(i)   Clone the repository and navigate to the project directory before running Makefiles.
(ii)  Update the PySpark ETL script with the necessary configuration parameters, such as API endpoint, query parameters, and output file paths.
(iii) Update the Makefile with the appropriate targets and commands for your environment and requirements.
(iv)  Run the ETL process using the following command:
      make pipeline
(v)   Monitor the execution and check the output files for the extracted and transformed adverse events data.

## Conclusion
By following the steps outlined in this document, we will be able to design and execute a PySpark ETL process to extract specific fields related to adverse event data. The process incorporates the use of JSON dataset as source data, data partitioning, and a Makefile for efficient execution.